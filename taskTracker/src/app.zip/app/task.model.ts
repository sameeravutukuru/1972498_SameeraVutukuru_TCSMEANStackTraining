export class task{
    constructor(public id:string, public name:string, public task:string, public deadline:string){}
}